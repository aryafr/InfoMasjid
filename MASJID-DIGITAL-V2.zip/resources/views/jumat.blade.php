<!-- resources/views/jumat.blade.php -->
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sistem Informasi Masjid - Jadwal Sholat Jumat</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
	<style>
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}
		
		body {
			font-family: 'Poppins', sans-serif;
			background: linear-gradient(135deg, #0a4d68, #088395);
			color: #ffffff;
			height: 100vh;
			width: 100vw;
			overflow: hidden;
			position: relative;
		}
		
		/* Kaligrafi */
		.kaligrafi {
			position: absolute;
			top: 20px;
			font-family: 'Amiri', serif;
			font-size: 5rem;
			opacity: 0.2;
			z-index: 0;
		}
		.kaligrafi-allah { right: 30px; }
		.kaligrafi-muhammad { left: 30px; }
		
		/* Container Utama - Fullscreen */
		.container {
			position: relative;
			z-index: 1;
			height: 100vh;
			width: 100%;
			display: flex;
			flex-direction: column;
			justify-content: center;
			padding: 20px 40px;
		}
		
		/* Header */
		.header {
			text-align: center;
			margin-bottom: 15px;
			flex-shrink: 0;
		}
		
		.header h1 {
			font-size: 2.2rem;
			background: linear-gradient(to right, #ffd700, #ffffff);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			margin-bottom: 5px;
		}
		
		.datetime {
			font-size: 0.9rem;
			background: rgba(0,0,0,0.3);
			display: inline-block;
			padding: 4px 12px;
			border-radius: 30px;
		}
		
		/* Main Card - Flex Grow untuk mengisi ruang */
		.jumat-card {
			background: rgba(255, 255, 255, 0.1);
			backdrop-filter: blur(10px);
			border-radius: 20px;
			padding: 15px 25px;
			border: 1px solid rgba(255, 215, 0, 0.3);
			box-shadow: 0 10px 40px rgba(0,0,0,0.2);
			flex: 1;
			display: flex;
			flex-direction: column;
			min-height: 0;
		}
		
		.jumat-header {
			text-align: center;
			border-bottom: 2px solid #ffd700;
			padding-bottom: 8px;
			margin-bottom: 15px;
			flex-shrink: 0;
		}
		
		.jumat-header i {
			font-size: 1.8rem;
			color: #ffd700;
			margin-bottom: 3px;
		}
		
		.jumat-header h2 {
			font-size: 1.3rem;
			color: #ffd700;
		}
		
		.jumat-header p {
			font-size: 0.7rem;
			opacity: 0.8;
		}
		
		/* Info Grid - Grid 4 kolom */
		.info-grid {
			display: grid;
			grid-template-columns: repeat(4, 1fr);
			gap: 12px;
			margin-bottom: 15px;
			flex-shrink: 0;
		}
		
		.info-item {
			background: rgba(0, 0, 0, 0.3);
			border-radius: 10px;
			padding: 8px;
			text-align: center;
		}
		
		.info-item i {
			font-size: 1.3rem;
			color: #ffd700;
			margin-bottom: 3px;
		}
		
		.info-item .label {
			font-size: 0.65rem;
			text-transform: uppercase;
			letter-spacing: 1px;
			opacity: 0.8;
		}
		
		.info-item .value {
			font-size: 0.9rem;
			font-weight: 600;
			margin-top: 3px;
		}
		
		/* Jadwal Table */
		.schedule-section {
			flex: 1;
			display: flex;
			flex-direction: column;
			min-height: 0;
		}
		
		.schedule-section h3 {
			text-align: center;
			font-size: 1rem;
			margin-bottom: 8px;
			color: #ffd700;
			flex-shrink: 0;
		}
		
		.schedule-table-wrapper {
			flex: 1;
			overflow-y: auto;
			min-height: 0;
		}
		
		.schedule-table {
			width: 100%;
			border-collapse: collapse;
		}
		
		.schedule-table th {
			background: #ffd700;
			color: #0a4d68;
			padding: 6px;
			text-align: center;
			font-weight: 600;
			font-size: 0.8rem;
		}
		
		.schedule-table td {
			padding: 6px;
			text-align: center;
			border-bottom: 1px solid rgba(255,255,255,0.2);
			font-size: 0.85rem;
		}
		
		/* Running Text Container - BARU DITAMBAHKAN */
		.running-text-container {
			background: rgba(0, 0, 0, 0.4);
			border-radius: 8px;
			padding: 8px 12px;
			margin-top: 12px;
			overflow: hidden;
			flex-shrink: 0;
		}
		
		.running-text {
			white-space: nowrap;
			animation: marquee 25s linear infinite;
			font-size: 0.8rem;
			letter-spacing: 0.5px;
		}
		
		.running-text i {
			margin-right: 8px;
			color: #ffd700;
		}
		
		@keyframes marquee {
			0% { transform: translateX(100%); }
			100% { transform: translateX(-100%); }
		}
		
		/* Footer */
		.footer {
			text-align: center;
			margin-top: 10px;
			padding-top: 6px;
			border-top: 1px solid rgba(255,255,255,0.2);
			font-size: 0.6rem;
			opacity: 0.6;
			flex-shrink: 0;
		}
		
		/* Scrollbar Styling */
		.schedule-table-wrapper::-webkit-scrollbar {
			width: 4px;
		}
		.schedule-table-wrapper::-webkit-scrollbar-track {
			background: rgba(255,255,255,0.1);
			border-radius: 10px;
		}
		.schedule-table-wrapper::-webkit-scrollbar-thumb {
			background: #ffd700;
			border-radius: 10px;
		}
		
		/* Responsive */
		@media (max-width: 1024px) {
			.container { padding: 15px 25px; }
			.info-grid { gap: 8px; }
			.info-item .value { font-size: 0.8rem; }
		}
	</style>
</head>
<body>
	<div class="kaligrafi kaligrafi-allah">ﷲ</div>
	<div class="kaligrafi kaligrafi-muhammad">ﷺ</div>
	
	<div class="container">
		<div class="header">
			<h1>{{ $settings['nama_aplikasi'] ?? 'Masjid Al-Ikhlas' }}</h1>
			<div class="datetime" id="datetime"></div>
		</div>
		
		<div class="jumat-card">
			<div class="jumat-header">
				<i class="fas fa-mosque"></i>
				<h2>Jadwal Sholat Jumat</h2>
				<p>Informasi Imam, Khatib & Muadzin</p>
			</div>
			
			@if($sholatJumat)
			<div class="info-grid">
				<div class="info-item">
					<i class="fas fa-calendar-alt"></i>
					<div class="label">Tanggal</div>
					<div class="value">{{ \Carbon\Carbon::parse($sholatJumat->tanggal)->translatedFormat('d/m/Y') }}</div>
				</div>
				<div class="info-item">
					<i class="fas fa-user"></i>
					<div class="label">Imam</div>
					<div class="value">{{ $sholatJumat->imam ?? 'Belum Ditentukan' }}</div>
				</div>
				<div class="info-item">
					<i class="fas fa-book"></i>
					<div class="label">Khatib</div>
					<div class="value">{{ $sholatJumat->khatib ?? 'Belum Ditentukan' }}</div>
				</div>
				<div class="info-item">
					<i class="fas fa-microphone-alt"></i>
					<div class="label">Muadzin</div>
					<div class="value">{{ $sholatJumat->muadzin ?? 'Belum Ditentukan' }}</div>
				</div>
			</div>
			
			<div class="schedule-section">
				<h3><i class="fas fa-clock"></i> Jadwal Sholat Hari Ini</h3>
				<div class="schedule-table-wrapper">
					<table class="schedule-table">
						<thead>
							<tr>
								<th>Sholat</th>
								<th>Waktu</th>
							</tr>
						</thead>
						<tbody>
							@foreach($jadwalSholat as $jadwal)
							<tr>
								<td style="font-weight: 500;">{{ $jadwal->nama_sholat }}</td>
								<td>{{ \Carbon\Carbon::parse($jadwal->waktu)->format('H:i') }} WIB</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
			@else
			<div class="text-center" style="padding: 40px;">
				<i class="fas fa-calendar-times fa-3x" style="opacity: 0.5;"></i>
				<p style="margin-top: 15px;">Belum ada jadwal sholat Jumat</p>
			</div>
			@endif
			
			<!-- RUNNING TEXT - BARU DITAMBAHKAN -->
			@if($settings['running_text'] ?? false)
			<div class="running-text-container">
				<div class="running-text">
					<i class="fas fa-bullhorn"></i> {{ $settings['running_text'] }}
				</div>
			</div>
			@endif
		</div>
		
		<div class="footer">
			{!! $settings['footer'] ?? 'Hak Cipta © 2025 Ali Mochtar Development System' !!}
		</div>
	</div>
	
	<script>
		function updateDateTime() {
			const now = new Date();
			const options = {
				weekday: 'long',
				year: 'numeric',
				month: 'long',
				day: 'numeric',
				hour: '2-digit',
				minute: '2-digit',
				timeZone: 'Asia/Jakarta'
			};
			document.getElementById('datetime').textContent = now.toLocaleString('id-ID', options);
		}
		updateDateTime();
		setInterval(updateDateTime, 1000);
	</script>
</body>
</html>