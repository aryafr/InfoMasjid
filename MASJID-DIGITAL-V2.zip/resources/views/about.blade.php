<!-- resources/views/about.blade.php -->
@extends('layouts.admin')
@section('title', 'Tentang Aplikasi')
@section('main-content')

<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Main Card -->
        <div class="card shadow mb-4 border-left-primary">
            <!-- Card Header with Logo -->
            <div class="card-header py-3 text-center bg-gradient-primary text-white">
                <img src="{{ isset($setting['logo']) ? asset('storage/' . $setting['logo']) : asset('img/default-logo.png') }}"
                alt="Logo Aplikasi"
                class="img-fluid mb-3"
                style="max-width: 100px;">
                <h4 class="m-0 font-weight-bold">{{ $setting->nama_aplikasi ?? 'Sistem Informasi Masjid Digital' }}</h4>
                <p class="mb-0 small">Solusi Digital untuk Manajemen Masjid dengan Tampilan TV Dinamis</p>
            </div>

            <!-- Card Body -->
            <div class="card-body">
                <!-- Introduction -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Tentang Aplikasi Ini</h5>
                    <p class="text-justify">
                        <strong>{{ $setting->nama_aplikasi ?? 'Sistem Informasi Masjid Digital' }}</strong> adalah solusi terintegrasi berbasis web untuk manajemen masjid modern yang dibangun dengan Laravel 12. Aplikasi ini menampilkan informasi masjid secara real-time pada layar TV digital dengan desain yang dinamis dan responsif.
                    </p>
                    <p class="text-justify">
                        Sistem ini dirancang khusus untuk menampilkan jadwal sholat, pengumuman, informasi keuangan, dan kegiatan masjid secara digital dengan tampilan yang elegan dan mudah dibaca dari jarak jauh. Dilengkapi dengan antarmuka admin yang lengkap untuk mengelola semua konten yang ditampilkan.
                    </p>
                </section>

                <!-- Main Features -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Fitur Utama</h5>
                    <div class="row">
                        <!-- Column 1 -->
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm border-left-success">
                                <div class="card-body">
                                    <h6 class="font-weight-bold text-success"><i class="fas fa-tv mr-2"></i>Tampilan TV Dinamis</h6>
                                    <p class="small text-justify">
                                        Menampilkan informasi masjid secara real-time pada layar TV dengan desain modern dan animasi yang menarik.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm border-left-success">
                                <div class="card-body">
                                    <h6 class="font-weight-bold text-success"><i class="fas fa-clock mr-2"></i>Jadwal Sholat Otomatis</h6>
                                    <p class="small text-justify">
                                        Menampilkan jadwal sholat dengan waktu yang akurat dan update otomatis sesuai lokasi masjid.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm border-left-success">
                                <div class="card-body">
                                    <h6 class="font-weight-bold text-success"><i class="fas fa-money-bill-wave mr-2"></i>Laporan Keuangan</h6>
                                    <p class="small text-justify">
                                        Menampilkan informasi keuangan masjid secara transparan dengan grafik dan detail pemasukan/pengeluaran.
                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Column 2 -->
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm border-left-success">
                                <div class="card-body">
                                    <h6 class="font-weight-bold text-success"><i class="fas fa-bullhorn mr-2"></i>Pengumuman Digital</h6>
                                    <p class="small text-justify">
                                        Menampilkan pengumuman penting masjid secara bergulir dengan efek animasi yang menarik.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm border-left-success">
                                <div class="card-body">
                                    <h6 class="font-weight-bold text-success"><i class="fas fa-sync-alt mr-2"></i>Auto-Update Jadwal</h6>
                                    <p class="small text-justify">
                                        Jadwal sholat diperbarui secara otomatis melalui API eksternal sesuai lokasi yang ditentukan.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 shadow-sm border-left-success">
                                <div class="card-body">
                                    <h6 class="font-weight-bold text-success"><i class="fas fa-exchange-alt mr-2"></i>Rotasi Halaman Dinamis</h6>
                                    <p class="small text-justify">
                                        Halaman tampilan TV berganti secara otomatis dengan interval yang dapat diatur sesuai kebutuhan.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- TV Display Features -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Fitur Tampilan TV</h5>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm h-100">
                                <div class="card-body text-center">
                                    <div class="bg-primary text-white rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; line-height: 50px; font-size: 20px;">1</div>
                                    <h6 class="font-weight-bold">Tampilan Waktu</h6>
                                    <p class="small">Menampilkan waktu sholat, tanggal Hijriah & Masehi secara real-time</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm h-100">
                                <div class="card-body text-center">
                                    <div class="bg-primary text-white rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; line-height: 50px; font-size: 20px;">2</div>
                                    <h6 class="font-weight-bold">Running Text</h6>
                                    <p class="small">Pengumuman bergulir dengan kecepatan yang dapat disesuaikan</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm h-100">
                                <div class="card-body text-center">
                                    <div class="bg-primary text-white rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; line-height: 50px; font-size: 20px;">3</div>
                                    <h6 class="font-weight-bold">Animasi Kaligrafi</h6>
                                    <p class="small">Elemen kaligrafi Islami dengan efek visual yang indah</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm h-100">
                                <div class="card-body text-center">
                                    <div class="bg-primary text-white rounded-circle mx-auto mb-3" style="width: 50px; height: 50px; line-height: 50px; font-size: 20px;">4</div>
                                    <h6 class="font-weight-bold">Rotasi Otomatis</h6>
                                    <p class="small">Halaman berganti otomatis dengan interval yang dapat diatur</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- New Feature: Rotation Display -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary"><i class="fas fa-exchange-alt mr-2"></i> Fitur Rotasi Halaman Dinamis</h5>
                    <div class="card shadow-sm border-left-warning">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="font-weight-bold">Apa itu Rotasi Halaman?</h6>
                                    <p class="small">
                                        Fitur ini memungkinkan tampilan TV untuk berganti secara otomatis antara beberapa halaman yang berbeda. 
                                        Anda dapat mengatur halaman mana saja yang ingin ditampilkan dan berapa lama waktu pergantiannya.
                                    </p>
                                    <h6 class="font-weight-bold mt-3">Keuntungan:</h6>
                                    <ul class="small">
                                        <li>Informasi lebih lengkap dan bervariasi</li>
                                        <li>Tampilan tidak monoton</li>
                                        <li>Dapat menampilkan lebih banyak informasi</li>
                                        <li>Mudah diatur melalui panel admin</li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="bg-light p-3 rounded">
                                        <h6 class="font-weight-bold">Cara Mengatur:</h6>
                                        <ol class="small">
                                            <li>Buka menu <strong>Rotasi Halaman</strong> di sidebar</li>
                                            <li>Aktifkan fitur rotasi dengan toggle switch</li>
                                            <li>Atur interval waktu pergantian (1-3600 detik)</li>
                                            <li>Pilih halaman yang ingin ditampilkan</li>
                                            <li>Klik Simpan Pengaturan</li>
                                            <li>Buka halaman utama untuk melihat hasilnya</li>
                                        </ol>
                                        <div class="alert alert-info mt-2 mb-0">
                                            <i class="fas fa-info-circle"></i> <strong>Info:</strong> Perubahan pengaturan akan langsung diterapkan tanpa perlu refresh browser!
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr class="my-3">
                            <div class="row text-center">
                                <div class="col-4">
                                    <span class="badge badge-primary p-2">Dashboard Lengkap</span>
                                </div>
                                <div class="col-4">
                                    <span class="badge badge-success p-2">Jadwal Sholat</span>
                                </div>
                                <div class="col-4">
                                    <span class="badge badge-info p-2">Rincian Keuangan</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Admin Features -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Fitur Admin</h5>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="font-weight-bold">Manajemen Konten</h6>
                                    <ul class="small">
                                        <li>Kelola jadwal sholat dan jadwal imam</li>
                                        <li>Posting pengumuman dan kegiatan masjid</li>
                                        <li>Input data keuangan dan laporan</li>
                                        <li>Atur tampilan TV (warna, font, layout)</li>
                                        <li>Upload gambar dan dokumen pendukung</li>
                                        <li><strong>Atur Rotasi Halaman TV</strong> - <span class="text-success">Fitur Baru!</span></li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="font-weight-bold">Sistem Keamanan</h6>
                                    <ul class="small">
                                        <li>Login dengan verifikasi dua faktor</li>
                                        <li>Pembatasan akses berdasarkan role</li>
                                        <li>Log aktivitas administrator</li>
                                        <li>Backup data otomatis</li>
                                        <li>Proteksi terhadap serangan cyber</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Technologies Used -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Teknologi yang Digunakan</h5>
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://laravel.com/img/logomark.min.svg" alt="Laravel" style="height: 40px;" class="mb-2">
                                    <h6 class="font-weight-bold">Laravel 12</h6>
                                    <p class="small">Framework PHP untuk backend</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://getbootstrap.com/docs/5.0/assets/brand/bootstrap-logo.svg" alt="Bootstrap" style="height: 40px;" class="mb-2">
                                    <h6 class="font-weight-bold">Bootstrap 5</h6>
                                    <p class="small">Framework CSS untuk frontend</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://jquery.com/jquery-wp-content/themes/jquery/img/logo-jquery.png" alt="jQuery" style="height: 40px;" class="mb-2">
                                    <h6 class="font-weight-bold">jQuery & AJAX</h6>
                                    <p class="small">Untuk update data real-time tanpa refresh</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card shadow-sm">
                                <div class="card-body text-center">
                                    <img src="https://www.mysql.com/common/logos/logo-mysql-170x115.png" alt="MySQL" style="height: 40px;" class="mb-2">
                                    <h6 class="font-weight-bold">MySQL</h6>
                                    <p class="small">Database management system</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Quick Guide -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Panduan Penggunaan</h5>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <div class="accordion" id="usageGuide">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h6 class="mb-0">
                                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne">
                                                <i class="fas fa-plus-circle mr-2"></i>Menampilkan di TV
                                            </button>
                                        </h6>
                                    </div>
                                    <div id="collapseOne" class="collapse show" data-parent="#usageGuide">
                                        <div class="card-body small">
                                            1. Buka browser di perangkat yang terhubung ke TV<br>
                                            2. Akses alamat aplikasi (contoh: http://masjidanda.tv)<br>
                                            3. Tekan F11 untuk mode layar penuh<br>
                                            4. Atur resolusi sesuai dengan layar TV<br>
                                            5. Sistem akan menampilkan informasi secara otomatis
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h6 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo">
                                                <i class="fas fa-plus-circle mr-2"></i>Update Jadwal Sholat
                                            </button>
                                        </h6>
                                    </div>
                                    <div id="collapseTwo" class="collapse" data-parent="#usageGuide">
                                        <div class="card-body small">
                                            1. Login sebagai admin<br>
                                            2. Akses menu Jadwal Sholat<br>
                                            3. Input waktu sholat sesuai lokasi masjid<br>
                                            4. Atur jadwal imam dan muadzin<br>
                                            5. Sistem akan update otomatis di tampilan TV
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <h6 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree">
                                                <i class="fas fa-plus-circle mr-2"></i>Posting Pengumuman
                                            </button>
                                        </h6>
                                    </div>
                                    <div id="collapseThree" class="collapse" data-parent="#usageGuide">
                                        <div class="card-body small">
                                            1. Login sebagai admin<br>
                                            2. Akses menu Pengumuman<br>
                                            3. Buat pengumuman baru<br>
                                            4. Atur tanggal dan prioritas tampilan<br>
                                            5. Pengumuman akan muncul di running text TV
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFour">
                                        <h6 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour">
                                                <i class="fas fa-plus-circle mr-2"></i>Atur Rotasi Halaman TV
                                            </button>
                                        </h6>
                                    </div>
                                    <div id="collapseFour" class="collapse" data-parent="#usageGuide">
                                        <div class="card-body small">
                                            1. Login sebagai admin<br>
                                            2. Akses menu Rotasi Halaman di sidebar<br>
                                            3. Aktifkan fitur rotasi<br>
                                            4. Atur interval waktu pergantian<br>
                                            5. Pilih halaman yang ingin ditampilkan<br>
                                            6. Klik Simpan - perubahan langsung berlaku!
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Version History -->
                <section class="mb-5">
                    <h5 class="font-weight-bold text-primary">Riwayat Versi</h5>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <ul class="small">
                                <li><strong>Versi 2.1.0</strong> ({{ now()->format('d F Y') }}) - <span class="text-success">Fitur Baru: Rotasi Halaman Dinamis</span>
                                    <ul>
                                        <li>Penambahan fitur rotasi halaman otomatis</li>
                                        <li>Interval rotasi dapat diatur (1-3600 detik)</li>
                                        <li>Pemilihan halaman yang akan dirotasi</li>
                                        <li>Update pengaturan real-time tanpa refresh</li>
                                    </ul>
                                </li>
                                <li><strong>Versi 2.0.0</strong> (Januari 2025) - Rilis Utama
                                    <ul>
                                        <li>Penambahan fitur auto-update jadwal sholat</li>
                                        <li>Peningkatan tampilan TV responsif</li>
                                        <li>Penambahan laporan keuangan</li>
                                    </ul>
                                </li>
                                <li><strong>Versi 1.0.0</strong> (Oktober 2024) - Rilis Awal</li>
                            </ul>
                        </div>
                    </div>
                </section>

                <!-- Developer Info -->
                <section class="text-center">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            {!! $setting->footer ?? '<p class="small text-muted">Dikembangkan oleh <a href="https://wa.me/628179851011" target="_blank" class="text-primary">Ali Mochtar Development System</a></p>' !!}
                            <p class="small text-muted mt-2">Versi Aplikasi: 2.1.0 (Update: {{ now()->format('d F Y') }})</p>
                            <p class="small text-muted">
                                <i class="fas fa-exchange-alt text-success"></i> Fitur Rotasi Halaman Aktif: 
                                @if($setting->rotation_enabled ?? false)
                                <span class="badge badge-success">AKTIF</span> (Interval: {{ $setting->rotation_interval ?? 10 }} detik)
                                @else
                                <span class="badge badge-secondary">NONAKTIF</span>
                                @endif
                            </p>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<!-- Custom CSS -->
<style>
    .card-header.bg-gradient-primary {
        background: linear-gradient(135deg, #0a4d68, #088395);
    }
    .border-left-primary {
        border-left: 4px solid #0a4d68;
    }
    .border-left-success {
        border-left: 4px solid #00a86b;
    }
    .border-left-warning {
        border-left: 4px solid #ffc107;
    }
    .accordion .card-header {
        background-color: rgba(10, 77, 104, 0.05);
    }
    .btn-link {
        color: #0a4d68;
        text-decoration: none;
    }
    .btn-link:hover {
        color: #088395;
    }
    .text-primary {
        color: #0a4d68 !important;
    }
    .badge-primary {
        background-color: #0a4d68;
    }
    .badge-success {
        background-color: #28a745;
    }
    .badge-info {
        background-color: #17a2b8;
    }
</style>

@endsection