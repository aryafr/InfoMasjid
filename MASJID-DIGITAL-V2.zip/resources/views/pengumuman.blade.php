<!-- resources/views/pengumuman.blade.php -->
<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sistem Informasi Masjid - Pengumuman</title>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
	<style>
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}
		
		body {
			font-family: 'Poppins', sans-serif;
			background: linear-gradient(135deg, #0a4d68, #088395);
			color: #ffffff;
			height: 100vh;
			width: 100vw;
			overflow: hidden;
			position: relative;
		}
		
		/* Kaligrafi */
		.kaligrafi {
			position: absolute;
			top: 15px;
			font-family: 'Amiri', serif;
			font-size: 4rem;
			opacity: 0.15;
			z-index: 0;
		}
		.kaligrafi-allah { right: 25px; }
		.kaligrafi-muhammad { left: 25px; }
		
		/* Container */
		.container {
			position: relative;
			z-index: 1;
			height: 100vh;
			width: 100%;
			display: flex;
			flex-direction: column;
			padding: 15px 25px;
		}
		
		/* Header */
		.header {
			text-align: center;
			margin-bottom: 10px;
			flex-shrink: 0;
		}
		
		.header h1 {
			font-size: 1.8rem;
			background: linear-gradient(to right, #ffd700, #ffffff);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			letter-spacing: 1px;
		}
		
		.datetime {
			font-size: 0.8rem;
			background: rgba(0,0,0,0.3);
			display: inline-block;
			padding: 3px 12px;
			border-radius: 20px;
			margin-top: 3px;
		}
		
		/* Announcement Grid - FIX 3 KOLOM */
		.announcement-grid {
			display: grid;
			grid-template-columns: repeat(3, 1fr);
			gap: 12px;
			flex: 1;
			min-height: 0;
			margin-bottom: 10px;
			align-content: start;
		}
		
		/* Announcement Card */
		.announcement-card {
			background: rgba(255, 255, 255, 0.12);
			backdrop-filter: blur(10px);
			border-radius: 12px;
			padding: 12px 15px;
			border-left: 4px solid #ffd700;
			transition: all 0.3s ease;
			display: flex;
			flex-direction: column;
			height: auto;
		}
		
		.announcement-card.featured {
			background: rgba(0, 0, 0, 0.35);
			border-left: 4px solid #ffd700;
			box-shadow: 0 2px 8px rgba(0,0,0,0.2);
		}
		
		/* Card Header */
		.card-header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-bottom: 8px;
			padding-bottom: 6px;
			border-bottom: 1px solid rgba(255,215,0,0.25);
			flex-shrink: 0;
		}
		
		.card-header i {
			font-size: 1.2rem;
			color: #ffd700;
		}
		
		/* PERUBAHAN: Ukuran font tanggal DIPERBESAR, sama dengan teks pengumuman */
		.date-badge {
			background: rgba(255, 215, 0, 0.2);
			color: #ffd700;
			padding: 4px 12px;
			border-radius: 20px;
			font-size: 0.9rem;
			font-weight: 600;
		}
		
		/* Announcement Content - Tulisan BESAR */
		.announcement-content {
			font-size: 0.95rem;
			line-height: 1.4;
			font-weight: 500;
			color: #fff;
			overflow: hidden;
			display: -webkit-box;
			-webkit-line-clamp: 4;
			-webkit-box-orient: vertical;
			word-break: break-word;
		}
		
		/* Running Text */
		.running-text-container {
			background: rgba(0, 0, 0, 0.4);
			border-radius: 6px;
			padding: 8px 12px;
			overflow: hidden;
			flex-shrink: 0;
			margin-top: 5px;
		}
		
		.running-text {
			white-space: nowrap;
			animation: marquee 25s linear infinite;
			font-size: 0.8rem;
			letter-spacing: 0.5px;
		}
		
		.running-text i {
			margin-right: 8px;
			color: #ffd700;
		}
		
		@keyframes marquee {
			0% { transform: translateX(100%); }
			100% { transform: translateX(-100%); }
		}
		
		/* Footer */
		.footer {
			text-align: center;
			margin-top: 8px;
			padding-top: 6px;
			border-top: 1px solid rgba(255,255,255,0.15);
			font-size: 0.6rem;
			opacity: 0.6;
			flex-shrink: 0;
		}
		
		/* Responsive untuk layar lebih kecil */
		@media (max-width: 1024px) {
			.container { padding: 12px 20px; }
			.announcement-grid { gap: 10px; }
			.announcement-card { padding: 10px 12px; }
			.announcement-content { font-size: 0.85rem; -webkit-line-clamp: 3; }
			.date-badge { font-size: 0.8rem; padding: 3px 10px; }
			.header h1 { font-size: 1.5rem; }
		}
		
		@media (max-width: 768px) {
			.announcement-grid { grid-template-columns: repeat(2, 1fr); }
		}
		
		/* Scrollbar */
		.announcement-grid::-webkit-scrollbar {
			width: 4px;
		}
		.announcement-grid::-webkit-scrollbar-track {
			background: rgba(255,255,255,0.1);
			border-radius: 4px;
		}
		.announcement-grid::-webkit-scrollbar-thumb {
			background: #ffd700;
			border-radius: 4px;
		}
		
		.announcement-grid {
			overflow-y: auto;
			scrollbar-width: thin;
		}
	</style>
</head>
<body>
	<div class="kaligrafi kaligrafi-allah">ﷲ</div>
	<div class="kaligrafi kaligrafi-muhammad">ﷺ</div>
	
	<div class="container">
		<div class="header">
			<h1>{{ $settings['nama_aplikasi'] ?? 'Masjid Al-Ikhlas' }}</h1>
			<div class="datetime" id="datetime"></div>
		</div>
		
		<div class="announcement-grid">
			@forelse($pengumuman as $index => $item)
			<div class="announcement-card {{ $index < 3 ? 'featured' : '' }}">
				<div class="card-header">
					<i class="fas fa-bullhorn"></i>
					<span class="date-badge">
						<i class="fas fa-calendar-alt" style="font-size: 0.7rem; margin-right: 4px;"></i>
						{{ \Carbon\Carbon::parse($item->tanggal)->translatedFormat('d M Y') }}
					</span>
				</div>
				<div class="announcement-content">
					{{ $item->isi }}
				</div>
			</div>
			@empty
			<div class="announcement-card" style="text-align: center; grid-column: span 3;">
				<div class="card-header">
					<i class="fas fa-info-circle"></i>
					<span class="date-badge">Info</span>
				</div>
				<div class="announcement-content" style="text-align: center;">
					<i class="fas fa-inbox fa-2x" style="opacity: 0.5; margin-bottom: 8px; display: block;"></i>
					Belum ada pengumuman tersedia
				</div>
			</div>
			@endforelse
		</div>
		
		@if($settings['running_text'] ?? false)
		<div class="running-text-container">
			<div class="running-text">
				<i class="fas fa-bullhorn"></i> {{ $settings['running_text'] }}
			</div>
		</div>
		@endif
		
		<div class="footer">
			{!! $settings['footer'] ?? 'Hak Cipta © 2025 Ali Mochtar Development System' !!}
		</div>
	</div>
	
	<script>
		function updateDateTime() {
			const now = new Date();
			const options = {
				weekday: 'long',
				year: 'numeric',
				month: 'long',
				day: 'numeric',
				hour: '2-digit',
				minute: '2-digit',
				timeZone: 'Asia/Jakarta'
			};
			document.getElementById('datetime').textContent = now.toLocaleString('id-ID', options);
		}
		updateDateTime();
		setInterval(updateDateTime, 1000);
	</script>
</body>
</html>