<!-- resources/views/layouts/admin.blade.php -->
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="{{ $setting['nama_aplikasi'] ?? 'Laravel SB Admin 2' }}">
    <meta name="author" content="Ali Mochtar Development System">

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $setting['nama_aplikasi'] ?? config('app.name', 'Laravel') }} - Admin Panel</title>

    <!-- Font Awesome -->
    <link href="{{ asset('vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    
    <!-- Bootstrap core CSS -->
    <link href="{{ asset('css/sb-admin-2.min.css') }}" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    
    <!-- SweetAlert2 -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Favicon -->
    <link href="{{ isset($setting['favicon']) ? asset('storage/' . $setting['favicon']) : asset('img/favicon.png') }}" rel="icon" type="image/png">

    <!-- Additional CSS -->
    @stack('styles')
</head>
<body id="page-top">
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/home') }}">
                <div class="sidebar-brand-icon">
                    <img src="{{ isset($setting['logo']) ? asset('storage/' . $setting['logo']) : asset('img/logo.png') }}" 
                    alt="Logo" class="img-fluid" style="max-width: 60px; max-height: 60px;">
                </div>
                <div class="sidebar-brand-text mx-3">{{ Str::limit($setting['nama_aplikasi'] ?? config('app.name', 'Laravel'), 15) }}</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item {{ request()->routeIs('home') ? 'active' : '' }}">
                <a class="nav-link" href="{{ route('home') }}">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            @auth
            @php
            $roleName = optional(auth()->user()->role)->name;
            @endphp

            @if ($roleName === 'admin')
            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Manajemen Data
            </div>

            <!-- Nav Item - Jadwal Sholat -->
            <li class="nav-item {{ request()->routeIs('jadwal_sholat.*') ? 'active' : '' }}">
                <a class="nav-link" href="{{ route('jadwal_sholat.index') }}">
                    <i class="fas fa-fw fa-pray"></i>
                    <span>Jadwal Sholat</span>
                </a>
            </li>

            <!-- Nav Item - Sholat Jumat -->
            <li class="nav-item {{ request()->routeIs('sholat_jumat.*') ? 'active' : '' }}">
                <a class="nav-link" href="{{ route('sholat_jumat.index') }}">
                    <i class="fas fa-fw fa-mosque"></i>
                    <span>Sholat Jumat</span>
                </a>
            </li>

            <!-- Nav Item - Pengumuman -->
            <li class="nav-item {{ request()->routeIs('pengumuman.*') ? 'active' : '' }}">
                <a class="nav-link" href="{{ route('pengumuman.index') }}">
                    <i class="fas fa-fw fa-bullhorn"></i>
                    <span>Pengumuman</span>
                </a>
            </li>

            <!-- Nav Item - Keuangan -->
            <li class="nav-item {{ request()->routeIs('keuangan.*') ? 'active' : '' }}">
                <a class="nav-link" href="{{ route('keuangan.index') }}">
                    <i class="fas fa-fw fa-money-bill"></i>
                    <span>Keuangan</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Pengaturan Sistem
            </div>

            <!-- Nav Item - Auto Update (FITUR BARU) -->
            <li class="nav-item {{ request()->routeIs('auto_update.*') ? 'active' : '' }}">
                <a class="nav-link" href="{{ route('auto_update.index') }}">
                    <i class="fas fa-fw fa-sync-alt"></i>
                    <span>Auto-Update Jadwal</span>
                    @if($setting->auto_update_jadwal ?? false)
                    <span class="badge badge-success ml-2" style="font-size: 10px;">AKTIF</span>
                    @else
                    <span class="badge badge-secondary ml-2" style="font-size: 10px;">NONAKTIF</span>
                    @endif
                </a>
            </li>

<!-- Nav Item - Rotasi Halaman (FITUR BARU) -->
<li class="nav-item {{ request()->routeIs('rotation.*') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('rotation.index') }}">
        <i class="fas fa-fw fa-exchange-alt"></i>
        <span>Rotasi Halaman</span>
        @if($setting->rotation_enabled ?? true)
        <span class="badge badge-success ml-2" style="font-size: 10px;">AKTIF</span>
        @else
        <span class="badge badge-secondary ml-2" style="font-size: 10px;">NONAKTIF</span>
        @endif
    </a>
</li>

<!-- Nav Item - Pengaturan Aplikasi -->
<li class="nav-item {{ request()->routeIs('settings.*') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('settings.edit') }}">
        <i class="fas fa-fw fa-cog"></i>
        <span>Pengaturan Aplikasi</span>
    </a>
</li>

<!-- Nav Item - Kelola Akun -->
<li class="nav-item {{ request()->routeIs('users.*') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('users.index') }}">
        <i class="fas fa-fw fa-user-cog"></i>
        <span>Kelola Akun</span>
    </a>
</li>

<!-- Nav Item - Roles -->


<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Laporan & Export
</div>

<!-- Nav Item - Export Data (Dropdown) -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseExport" 
    aria-expanded="true" aria-controls="collapseExport">
    <i class="fas fa-fw fa-download"></i>
    <span>Export Data</span>
</a>
<div id="collapseExport" class="collapse" aria-labelledby="headingExport" 
data-parent="#accordionSidebar">
<div class="bg-white py-2 collapse-inner rounded">
    <h6 class="collapse-header">Pilih Data:</h6>
    <a class="collapse-item" href="{{ route('export.jadwal-sholat') }}">
        <i class="fas fa-pray text-primary"></i> Jadwal Sholat
    </a>

    <a class="collapse-item" href="{{ route('export.pengumuman') }}">
        <i class="fas fa-bullhorn text-warning"></i> Pengumuman
    </a>
</div>
</div>
</li>

<!-- Nav Item - Laporan Keuangan -->
<li class="nav-item {{ request()->routeIs('laporan.keuangan*') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('laporan.keuangan') }}">
        <i class="fas fa-fw fa-chart-bar"></i>
        <span>Laporan Keuangan</span>
    </a>
</li>

@endif

@if ($roleName === 'petugas')
<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Menu Petugas
</div>

<!-- Nav Item - Jadwal Sholat (Read Only) -->
<li class="nav-item">
    <a class="nav-link" href="{{ route('jadwal_sholat.index') }}">
        <i class="fas fa-fw fa-pray"></i>
        <span>Lihat Jadwal Sholat</span>
    </a>
</li>

<!-- Nav Item - Pengumuman -->
<li class="nav-item">
    <a class="nav-link" href="{{ route('pengumuman.index') }}">
        <i class="fas fa-fw fa-bullhorn"></i>
        <span>Kelola Pengumuman</span>
    </a>
</li>

<!-- Nav Item - Keuangan (Input) -->
<li class="nav-item">
    <a class="nav-link" href="{{ route('keuangan.index') }}">
        <i class="fas fa-fw fa-money-bill"></i>
        <span>Input Keuangan</span>
    </a>
</li>
@endif

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Akun
</div>

<!-- Nav Item - Profile -->
<li class="nav-item {{ request()->routeIs('profile') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('profile') }}">
        <i class="fas fa-fw fa-user"></i>
        <span>Profil Saya</span>
    </a>
</li>

<!-- Nav Item - About -->
<li class="nav-item {{ request()->routeIs('about') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('about') }}">
        <i class="fas fa-fw fa-hands-helping"></i>
        <span>Tentang Aplikasi</span>
    </a>
</li>

@endauth

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

            <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fa fa-bars"></i>
            </button>

            <!-- Topbar Search -->
            <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Cari..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="button">
                            <i class="fas fa-search fa-sm"></i>
                        </button>
                    </div>
                </div>
            </form>

            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto">

                <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                <li class="nav-item dropdown no-arrow d-sm-none">
                    <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-search fa-fw"></i>
                    </a>
                    <!-- Dropdown - Messages -->
                    <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                        <form class="form-inline mr-auto w-100 navbar-search">
                            <div class="input-group">
                                <input type="text" class="form-control bg-light border-0 small" placeholder="Cari..." aria-label="Search" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="button">
                                        <i class="fas fa-search fa-sm"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </li>

                <!-- Nav Item - Alerts -->
                <li class="nav-item dropdown no-arrow mx-1">
                    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell fa-fw"></i>
                        <!-- Counter - Alerts -->
                        <span class="badge badge-danger badge-counter">3+</span>
                    </a>
                    <!-- Dropdown - Alerts -->
                    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
                        <h6 class="dropdown-header">
                            Notifikasi
                        </h6>
                        <a class="dropdown-item d-flex align-items-center" href="#">
                            <div class="mr-3">
                                <div class="icon-circle bg-primary">
                                    <i class="fas fa-file-alt text-white"></i>
                                </div>
                            </div>
                            <div>
                                <div class="small text-gray-500">Update Tersedia</div>
                                <span class="font-weight-bold">Jadwal Sholat perlu diupdate?</span>
                            </div>
                        </a>
                        <a class="dropdown-item text-center small text-gray-500" href="#">Lihat Semua Notifikasi</a>
                    </div>
                </li>

                <div class="topbar-divider d-none d-sm-block"></div>

                <!-- Nav Item - User Information -->
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="mr-2 d-none d-lg-inline text-gray-600 small">{{ Auth::user()->name }}</span>
                        <div class="img-profile rounded-circle bg-primary d-flex align-items-center justify-content-center text-white" 
                        style="width: 32px; height: 32px; font-weight: bold;">
                        {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                    </div>
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="{{ route('profile') }}">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profil
                    </a>
                    <a class="dropdown-item" href="{{ route('settings.edit') }}">
                        <i class="fas fa-cog fa-sm fa-fw mr-2 text-gray-400"></i>
                        Pengaturan
                    </a>
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                        Aktivitas
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Keluar
                    </a>
                </div>
            </li>

        </ul>

    </nav>
    <!-- End of Topbar -->

    <!-- Begin Page Content -->
    <div class="container-fluid">
        @yield('main-content')
    </div>
    <!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            @if(isset($setting['footer']))
            {!! $setting['footer'] !!}
            @else
            <span>Copyright &copy; <a href="https://wa.me/628179851011" target="_blank" style="text-decoration: none; color: gray;">Ali Mochtar Development System</a> {{ now()->year }}</span>
            @endif
            <span class="ml-2">|</span>
            <span class="ml-2">Versi 2.0 (Dengan Auto-Update)</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Siap Untuk Keluar?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Pilih "Keluar" di bawah jika Anda siap untuk mengakhiri sesi Anda saat ini.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                <a class="btn btn-danger" href="{{ route('logout') }}" 
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i> Keluar
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
        </div>
    </div>
</div>
</div>

<!-- Scripts -->
<!-- jQuery -->
<script src="{{ asset('vendor/jquery/jquery.min.js') }}"></script>

<!-- Bootstrap -->
<script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>

<!-- jQuery Easing -->
<script src="{{ asset('vendor/jquery-easing/jquery.easing.min.js') }}"></script>

<!-- SB Admin 2 -->
<script src="{{ asset('js/sb-admin-2.min.js') }}"></script>

<!-- Chart.js (optional) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Custom Scripts -->
<script>
        // Auto-hide alert setelah 5 detik
    $(document).ready(function() {
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 5000);
    });

        // Konfirmasi sebelum menghapus
    function confirmDelete(event, formId) {
        event.preventDefault();
        if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
            document.getElementById(formId).submit();
        }
    }

        // Format Rupiah
    function formatRupiah(angka) {
        var number_string = angka.toString().replace(/[^,\d]/g, ''),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);
        
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return 'Rp ' + rupiah;
    }
</script>

<!-- Stack untuk scripts tambahan -->
@stack('scripts')
</body>
</html>