<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pengumuman extends Model
{
	protected $table = 'pengumuman';
	
	protected $fillable = [
		'isi',
		'tanggal',
	];

	public $timestamps = true;
}